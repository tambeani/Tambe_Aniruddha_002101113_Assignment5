/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Menu;

import Business.Orders.OrderItem;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class Food {
    
    ArrayList<OrderItem> orderItems;
    double price;
    String dishName;

    public double getPrice() {
        return price;
    }
    
    @Override
    public String toString(){
        return this.dishName;
    }
}
