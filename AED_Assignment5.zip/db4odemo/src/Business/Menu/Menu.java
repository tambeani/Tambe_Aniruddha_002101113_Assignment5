/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Menu;

import Business.Orders.OrderItem;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class Menu {
    
    ArrayList<Food> allDishes;
    
    public Menu(){
        this.allDishes = new ArrayList<Food>();
    }

    public ArrayList<Food> getAllDishes() {
        return allDishes;
    }

    public void setAllDishes(ArrayList<Food> allDishes) {
        this.allDishes = allDishes;
    }

    public Food addNewDish(){
        Food foodNew = new Food();
        this.getAllDishes().add(foodNew);
        return foodNew;
    
    }
    
    public Food getFoodByOrderItem(OrderItem orderItem){
        
        for(Food food:this.getAllDishes()){
            
            if(food.getOrderItems().contains(orderItem)){
                return food;
            }
            
        }
        return null;
    }
    
    
}
