/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Restaurant;

import Business.Employee.Employee;
import Business.Menu.Menu;

/**
 *
 * @author user
 */
public class Restaurant {
    
    String name;
    Menu menu;
    Employee restaurantManager;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Menu getMenu() {
        return menu;
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }

    public Employee getRestaurantManager() {
        return restaurantManager;
    }

    public void setRestaurantManager(Employee restaurantManager) {
        this.restaurantManager = restaurantManager;
    }
    
    
}
