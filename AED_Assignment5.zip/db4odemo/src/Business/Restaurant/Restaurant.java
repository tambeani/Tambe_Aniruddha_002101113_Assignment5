/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Restaurant;

import Business.Employee.Employee;
import Business.Menu.Menu;
import Business.Orders.Order;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class Restaurant {
    
    String name;
    Menu menu;
    Employee restaurantManager;
    
    public Restaurant(){
        menu = new Menu();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Menu getMenu() {
        return menu;
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }

    public Employee getRestaurantManager() {
        return restaurantManager;
    }

    public void setRestaurantManager(Employee restaurantManager) {
        this.restaurantManager = restaurantManager;
    }
    
    @Override
    public String toString(){
        return this.getName();
    }
}
