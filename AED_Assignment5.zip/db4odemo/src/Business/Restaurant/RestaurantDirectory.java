/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Restaurant;

import Business.Employee.Employee;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class RestaurantDirectory {
    
    ArrayList<Restaurant> restaurantList;
    
    public RestaurantDirectory(){
    
        restaurantList = new ArrayList<Restaurant>();
    
    }
    
    public Restaurant getRestaurantForManager(Employee emp){
        
        for(Restaurant res: restaurantList){
            
            if(res.getRestaurantManager().equals(emp)){
                return res;
            }
            
        }
        return null;
    }
    

    
    public Restaurant IsMatchByName(String resName){
    
        for(Restaurant res: restaurantList){
        
            if(res.getName().equals(resName)){
                return res;
            }
        }
        
        return null;
    
    }
    public ArrayList<Restaurant> getRestaurantList() {
        return restaurantList;
    }

    public Restaurant addARestaurant(){
        Restaurant newRes = new Restaurant();
        restaurantList.add(newRes);
        return newRes;
    }
    
    
}
