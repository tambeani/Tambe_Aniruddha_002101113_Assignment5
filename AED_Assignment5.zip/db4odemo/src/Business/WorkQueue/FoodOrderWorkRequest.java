/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.Orders.Order;

/**
 *
 * @author raunak
 */
public class FoodOrderWorkRequest extends WorkRequest{
    
    private String status;
    private Order order;

    public void setOrder(Order order) {
        this.order = order;
    }

    public String getStatus() {
        return status;
    }

    public Order getOrder() {
        return order;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
}
