/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Employee;

import java.util.ArrayList;

/**
 *
 * @author raunak
 */
public class EmployeeDirectory {
    
    private ArrayList<Employee> employeeList;

    public EmployeeDirectory() {
        employeeList = new ArrayList();
    }

    public ArrayList<Employee> getEmployeeList() {
        return employeeList;
    }
    
    public Employee createEmployee(String name){
        
        Employee employee = new Employee();
        
        int size = this.getEmployeeList().size();
        if(size>0){
            int id = this.getEmployeeList().get(size-1).getId()+1;
            int count = id + 1;
            employee.setId(id);
            employee.setCount(count);
        }
        
        employee.setName(name);
        employeeList.add(employee);
        return employee;
    }
    
    public Employee getEmployeeById(int id){
        
        for(Employee emp:employeeList){
            
            if(emp.getId() == id){
                return emp;
            }
        }
        return null;
    }
}