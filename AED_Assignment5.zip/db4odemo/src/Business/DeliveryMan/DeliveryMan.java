/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.DeliveryMan;

import Business.Employee.Employee;

/**
 *
 * @author harold
 */
public class DeliveryMan extends Employee{
    
    private int id;
    private static int count = 0;
    private boolean status;

    public DeliveryMan(){
        super();
        count += 1;
        this.id = count;
        status = true;
        
    }

    public void setStatus(boolean status) {
        this.status = status;
    }


    public boolean isStatus() {
        return status;
    }

    public int getId() {
        return id;
    }
    
    public boolean isMatch(int id){
        return this.getId() == id;
    }
    
    @Override
    public String toString(){
        return this.getName();
    }
    
}
