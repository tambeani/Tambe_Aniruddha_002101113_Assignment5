/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.DeliveryMan;

import Business.Customer.Customer;
import java.util.ArrayList;

/**
 *
 * @author harold
 */
public class DeliveryManDirectory {
    
    ArrayList<DeliveryMan> deliverymen;

    public DeliveryManDirectory(){
        deliverymen = new ArrayList<DeliveryMan>();
    }
    
    public ArrayList<DeliveryMan> getDeliveryMenList() {
        return this.deliverymen;
    }

    public DeliveryMan addDeliveryMen(String name) {
        DeliveryMan newDelivery = new DeliveryMan();
        newDelivery.setName(name);
        
        this.deliverymen.add(newDelivery);
        
        return newDelivery;
    }
    
    public void deleteDeliveryMan(DeliveryMan deliveryMan){
        this.deliverymen.remove(deliveryMan);
    }
    
    public DeliveryMan getDelivery(int id){
        
        for(DeliveryMan del: this.getDeliveryMenList()){
        
            if(del.isMatch(id)){
                return del;
            }
            
        }
         return null;
    }
    
}
