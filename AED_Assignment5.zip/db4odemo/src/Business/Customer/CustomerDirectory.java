/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Customer;

import java.util.ArrayList;
import jdk.nashorn.internal.runtime.arrays.ArrayLikeIterator;

/**
 *
 * @author harold
 */
public class CustomerDirectory {
    ArrayList<Customer> customers;

    public CustomerDirectory(){
        customers = new ArrayList<Customer>();
    }
    
    public ArrayList<Customer> getCustomerList() {
        return this.customers;
    }

    public Customer addCustomer(String name) {
        Customer newCus = new Customer();
        newCus.setName(name);
        this.customers.add(newCus);
        
        return newCus;
    }
    
    public void deleteCustomer(Customer cus){
        this.customers.remove(cus);
    }
    
    public Customer getCustomer(int id){
        
        for(Customer cus: this.getCustomerList()){
        
            if(cus.isMatch(id)){
                return cus;
            }
            
        }
         return null;
    }
    
   
    
}
