/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Orders;

/**
 *
 * @author user
 */
public class OrderItem {
    
    int quantity;
    double orderPrice;

    public int getQuantity() {
        return quantity;
    }

    public double getOrderPrice() {
        return orderPrice;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setOrderPrice(double orderPrice) {
        this.orderPrice = orderPrice;
    }
    
    
    
}
